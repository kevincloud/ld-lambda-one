VERSION = "9.7.2" # x-release-please-version
